import random
import time

from SimpleCliffEnv import SimpleCliffEnv


def run_rollout(env, actions):
    trace = []
    s = env.reset()
    done = False
    while not done:
        # env.show()
        # time.sleep(0.1)
        a = random.choice(actions)
        s_next, r, done = env.step(a)
        trace.append([s, a, r])
        s = s_next
    # env.show()
    return trace


def run_montecarlo(env, gamma, num_of_episodes):
    actions = env.action_space
    v_initial_state = []
    for episode in range(num_of_episodes):
        trace = run_rollout(env, actions)

        # Computing the return at the initial state
        g = 0.0
        for s, a, r in trace[::-1]:
            g = r + gamma * g
        v_initial_state.append(g)

        # Showing current estimate
        if episode % 10000 == 0:
            print(f"Ep. {episode}. Current return: {g:0.3f}. Avg return: {sum(v_initial_state)/len(v_initial_state):0.3f}")


if __name__ == '__main__':
    num_of_episodes = 500001
    gamma = 0.99
    env = SimpleCliffEnv()
    run_montecarlo(env, gamma, num_of_episodes)
